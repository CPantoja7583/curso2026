# API REST CRUD de Personas

API simple con Express + PostgreSQL. Sin vistas, solo JSON.

## Instalación

```bash
npm install
```

## Configuración

1. Copia `.env.example` a `.env`:

```bash
cp .env.example .env
```

2. Edita `.env` con tu password de PostgreSQL.

3. Crea la tabla en PostgreSQL ejecutando el script desde pgAdmin o:

```bash
psql -U postgres -d postgres -f sql/init.sql
```

## Correr

```bash
node index.js
```

Deberías ver:

```
✓ Conectado a PostgreSQL
Servidor en http://localhost:3000
```

## Endpoints

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/personas` | Listar todas |
| GET | `/personas/:id` | Obtener una por ID |
| POST | `/personas` | Crear una nueva |
| PUT | `/personas/:id` | Actualizar |
| DELETE | `/personas/:id` | Eliminar |

## Ejemplos con curl

### Listar todas
```bash
curl http://localhost:3000/personas
```

### Obtener una por ID
```bash
curl http://localhost:3000/personas/1
```

### Crear una nueva
```bash
curl -X POST http://localhost:3000/personas \
  -H "Content-Type: application/json" \
  -d '{"nombres":"Ana","apellidos":"Soto","edad":30,"email":"[email protected]"}'
```

### Actualizar
```bash
curl -X PUT http://localhost:3000/personas/1 \
  -H "Content-Type: application/json" \
  -d '{"nombres":"Maria","apellidos":"Lopez","edad":29,"email":"[email protected]"}'
```

### Eliminar
```bash
curl -X DELETE http://localhost:3000/personas/2
```

## Probar con Postman / Thunder Client

1. Crea una colección con las 5 rutas de arriba.
2. Para POST y PUT, en el body elige **JSON** y pega:

```json
{
  "nombres": "Ana",
  "apellidos": "Soto",
  "edad": 30,
  "email": "[email protected]"
}
```

## Esquema de la tabla

```sql
CREATE TABLE personas (
  id          SERIAL PRIMARY KEY,
  nombres     VARCHAR(100) NOT NULL,
  apellidos   VARCHAR(100) NOT NULL,
  edad        INTEGER,
  email       VARCHAR(150),
  creado_en   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```
