// ============================================
// API REST: CRUD de personas con PostgreSQL
// Sin vistas, solo JSON. Para probar con Postman, curl o Thunder Client.
// ============================================

require("dotenv").config();
const express = require("express");
const { Pool } = require("pg");

const app = express();
app.use(express.json());   // para leer JSON del body en POST/PUT

// ============================================
// Conexión a PostgreSQL
// ============================================
const pool = new Pool({
  host:     process.env.DB_HOST,
  port:     process.env.DB_PORT,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

pool.query("SELECT NOW()")
  .then(() => console.log("✓ Conectado a PostgreSQL"))
  .catch(err => console.error("✗ Error conectando:", err.message));

// ============================================
// RUTAS CRUD
// ============================================

// GET /personas — Listar todas
app.get("/personas", async (req, res) => {
  try {
    const resultado = await pool.query(
      "SELECT * FROM personas ORDER BY id"
    );
    res.json(resultado.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /personas/:id — Obtener una por ID
app.get("/personas/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const resultado = await pool.query(
      "SELECT * FROM personas WHERE id = $1",
      [id]
    );

    if (resultado.rows.length === 0) {
      return res.status(404).json({ error: "Persona no encontrada" });
    }

    res.json(resultado.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /personas — Crear una nueva
app.post("/personas", async (req, res) => {
  try {
    const { nombres, apellidos, edad, email } = req.body;

    // Validación básica
    if (!nombres || !apellidos) {
      return res.status(400).json({
        error: "nombres y apellidos son obligatorios"
      });
    }

    const resultado = await pool.query(
      `INSERT INTO personas (nombres, apellidos, edad, email)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [nombres, apellidos, edad, email]
    );

    res.status(201).json(resultado.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// PUT /personas/:id — Actualizar una persona
app.put("/personas/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { nombres, apellidos, edad, email } = req.body;

    const resultado = await pool.query(
      `UPDATE personas
       SET nombres = $1, apellidos = $2, edad = $3, email = $4
       WHERE id = $5
       RETURNING *`,
      [nombres, apellidos, edad, email, id]
    );

    if (resultado.rows.length === 0) {
      return res.status(404).json({ error: "Persona no encontrada" });
    }

    res.json(resultado.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE /personas/:id — Eliminar una persona
app.delete("/personas/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const resultado = await pool.query(
      "DELETE FROM personas WHERE id = $1 RETURNING *",
      [id]
    );

    if (resultado.rows.length === 0) {
      return res.status(404).json({ error: "Persona no encontrada" });
    }

    res.json({ mensaje: "Persona eliminada", persona: resultado.rows[0] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// Levantar servidor
// ============================================
app.listen(3000, () => {
  console.log("Servidor en http://localhost:3000");
  console.log("\nEndpoints:");
  console.log("  GET    /personas");
  console.log("  GET    /personas/:id");
  console.log("  POST   /personas");
  console.log("  PUT    /personas/:id");
  console.log("  DELETE /personas/:id");
});
