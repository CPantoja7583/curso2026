-- ============================================
-- Crear tabla de personas en el schema public
-- ============================================
-- Ejecutar desde pgAdmin o con:
--   psql -U postgres -d postgres -f sql/init.sql

CREATE TABLE IF NOT EXISTS public.personas (
  id          SERIAL PRIMARY KEY,
  nombres     VARCHAR(100) NOT NULL,
  apellidos   VARCHAR(100) NOT NULL,
  edad        INTEGER,
  email       VARCHAR(150),
  creado_en   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Datos de ejemplo (opcionales)
INSERT INTO public.personas (nombres, apellidos, edad, email) VALUES
  ('Maria',  'Lopez',     28, '[email protected]'),
  ('Juan',   'Perez',     35, '[email protected]'),
  ('Camila', 'Rodriguez', 24, '[email protected]');

-- Verificación
SELECT * FROM public.personas;
