// ============================================
// PASO 7: Persistencia en archivo + subida de archivos
// ============================================
// Cambios respecto al paso anterior:
//   1. Las personas se guardan/leen desde data/personas.json (no se pierden al reiniciar).
//   2. Se puede subir una foto de perfil con multer (se guarda en public/uploads/).

const express = require("express");
const { engine } = require("express-handlebars");
const fs = require("fs");           // <-- NUEVO: manejo de archivos
const path = require("path");        // <-- NUEVO: rutas seguras del sistema
const multer = require("multer");    // <-- NUEVO: middleware para subir archivos

const app = express();

// ============================================
// Configuración de Handlebars
// ============================================
app.engine("hbs", engine({
  extname: ".hbs",
  defaultLayout: "main"
}));
app.set("view engine", "hbs");
app.set("views", "./views");

app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));

// ============================================
// PERSISTENCIA EN ARCHIVO PLANO (JSON)
// ============================================
// Ruta del archivo donde guardamos los datos
const ARCHIVO_PERSONAS = path.join(__dirname, "data", "personas.json");

// Carga las personas desde el archivo (si existe)
function cargarPersonas() {
  try {
    // Si no existe el archivo todavía, devolvemos arreglo vacío
    if (!fs.existsSync(ARCHIVO_PERSONAS)) {
      return [];
    }
    const contenido = fs.readFileSync(ARCHIVO_PERSONAS, "utf-8");
    return JSON.parse(contenido);
  } catch (error) {
    console.error("Error leyendo personas.json:", error.message);
    return [];
  }
}

// Guarda el arreglo de personas en el archivo
function guardarPersonas(personas) {
  // El segundo argumento (null, 2) hace que el JSON quede indentado y legible
  fs.writeFileSync(ARCHIVO_PERSONAS, JSON.stringify(personas, null, 2), "utf-8");
}

// Cargamos las personas al iniciar el servidor
let personas = cargarPersonas();

// ============================================
// CONFIGURACIÓN DE MULTER (subida de archivos)
// ============================================
// Multer es un middleware que procesa formularios con archivos.
// Le decimos DÓNDE guardar y CÓMO nombrar los archivos.
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Las fotos se guardan en public/uploads para servirlas como estáticas
    cb(null, "public/uploads");
  },
  filename: (req, file, cb) => {
    // Renombramos el archivo para evitar colisiones: timestamp + extensión original
    const extension = path.extname(file.originalname);
    const nombreUnico = Date.now() + "-" + Math.round(Math.random() * 1e6) + extension;
    cb(null, nombreUnico);
  }
});

// Filtro: solo permitimos imágenes
const filtroImagenes = (req, file, cb) => {
  if (file.mimetype.startsWith("image/")) {
    cb(null, true);
  } else {
    cb(new Error("Solo se permiten imágenes"), false);
  }
};

const upload = multer({
  storage: storage,
  fileFilter: filtroImagenes,
  limits: { fileSize: 2 * 1024 * 1024 }  // máximo 2 MB
});

// ============================================
// RUTAS
// ============================================

app.get("/", (req, res) => {
  res.redirect("/inicio");
});

app.get("/inicio", (req, res) => {
  res.render("inicio", {
    titulo: "Inicio",
    nombre: "Pedro Perez",
    cantidadPersonas: personas.length
  });
});

// Formulario para crear persona (ahora con campo de foto)
app.get("/personas/nuevo", (req, res) => {
  res.render("nuevo", {
    titulo: "Crear Persona"
  });
});

// Crear persona — fíjate en el upload.single("foto") como middleware
// "foto" es el atributo name del input del formulario
app.post("/personas", upload.single("foto"), (req, res) => {
  const { nombres, apellidos, edad, direccion, password } = req.body;

  // req.file existe solo si el usuario subió una foto
  // Guardamos la RUTA pública de la foto (relativa a /public)
  const foto = req.file ? "/uploads/" + req.file.filename : null;

  personas.push({
    nombres: nombres,
    apellidos: apellidos,
    edad: edad,
    direccion: direccion,
    password: password,
    foto: foto,
    creadoEn: new Date().toISOString()
  });

  // GUARDAR EN ARCHIVO (lo nuevo)
  guardarPersonas(personas);

  res.redirect("/personas");
});

// Lista de personas (lee desde memoria, que ya está sincronizada con el archivo)
app.get("/personas", (req, res) => {
  res.render("personas", {
    titulo: "Lista de Personas",
    personas: personas
  });
});

// ============================================
// Manejo de errores de multer
// ============================================
// Si multer rechaza un archivo (muy grande, no es imagen), llega aquí
app.use((err, req, res, next) => {
  if (err) {
    return res.status(400).render("nuevo", {
      titulo: "Crear Persona",
      error: err.message
    });
  }
  next();
});

app.listen(3000, () => {
  console.log("Servidor iniciado en http://localhost:3000");
});
