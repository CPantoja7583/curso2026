# Paso 7: Persistencia en archivo + Subida de archivos

Versión actualizada del ejercicio de personas con dos mejoras:

## Lo nuevo

### 1. Persistencia en archivo JSON
Las personas ya NO se pierden al reiniciar el servidor. Se guardan en `data/personas.json`.

**Cómo funciona:**
- Al iniciar el servidor, se lee el archivo (si existe) y se carga al arreglo en memoria.
- Cada vez que se crea una persona, se escribe el arreglo completo de vuelta al archivo.
- Si el archivo no existe todavía, se trabaja con un arreglo vacío.

### 2. Subida de archivos con multer
El formulario ahora permite subir una foto de perfil.

**Cómo funciona:**
- El form tiene `enctype="multipart/form-data"` (sin esto el archivo NO llega).
- `multer` procesa el archivo y lo guarda en `public/uploads/`.
- El archivo se renombra con timestamp para evitar colisiones.
- Solo se aceptan imágenes (JPG, PNG, etc.) y máximo 2MB.
- La ruta de la foto se guarda en `personas.json` junto a los demás datos.

## Cómo correr

```bash
npm install
npm start
```

Abre **http://localhost:3000/inicio**

## Estructura

```
paso-7-persistencia/
├── index.js
├── package.json
├── data/
│   └── personas.json       ← se crea solo al guardar la primera persona
├── public/
│   ├── css/estilos.css
│   └── uploads/            ← aquí caen las fotos subidas
└── views/
    ├── layouts/main.hbs
    ├── partials/menu.hbs
    ├── inicio.hbs
    ├── nuevo.hbs            ← formulario con campo file
    └── personas.hbs         ← lista con avatares
```

## Probar la persistencia

1. Inicia el servidor.
2. Crea 2 o 3 personas.
3. Detén el servidor con `Ctrl+C`.
4. Inicia de nuevo con `npm start`.
5. Ve a `/personas` → las personas siguen ahí.
6. Mira el archivo `data/personas.json`, debería tener los datos.

## Dependencias nuevas

- **multer** — middleware oficial de Express para manejar `multipart/form-data` (subida de archivos).
- **fs** y **path** — módulos nativos de Node.js para leer/escribir archivos.
